# 屏学助手 ScreenCoach 1.0.0

Android 11+ 学习辅助原型：DeepSeek 识图答题 / 翻译，支持本机题库和翻译词库。

## 文件

| 文件 | 说明 |
|---|---|
| `ScreenCoach-1.0.0-release.apk` | Android 安装包（minSdk 30 / targetSdk 33） |
| `ScreenCoach-1.0.0-source.zip` | 完整 Android 工程源码、Gradle wrapper、构建脚本、README |
| `SHA256SUMS.txt` | 上述文件的 SHA-256 |

## 主要功能

- 默认答题模式 / 翻译模式；翻译模式有语言二级菜单，默认中英双向。
- 题库和翻译词库导入：题库支持拍照、相册、文件；词库支持文件。
- 本机 SQLite 题库/词库；可分别开关“相似题目优先使用题库”“匹配翻译优先使用词库”。
- 大悬浮窗、小像素浮窗、常驻通知、用户搜题模式、思考强度、FLAG_SECURE。
- 只连接 DeepSeek 官方接口 `https://api.deepseek.com`，模型 `deepseek-flash`。

## 安装

1. Android 11+ 允许安装未知来源应用。
2. 安装 `ScreenCoach-1.0.0-release.apk`。
3. 打开应用，填入 DeepSeek API Key。
4. 授予悬浮窗、通知和无障碍权限。
5. 选择模式、导入题库/词库、开始识别。

详细使用、文件格式和限制见源码包内的 `README.md`。

## 关于 release APK

- APK 已签名且未设置 `android:debuggable`。
- 当前签名证书为本地调试证书（`CN=Android Debug`）。适合个人安装和测试；公开分发/上架请用你自己的 release keystore 重新签名。
- 出于安全考虑，源码包和压缩包中不包含签名 keystore。
- 关闭了 cleartext HTTP，只允许 HTTPS 访问 DeepSeek 官方接口。

## 构建源码

```bash
cd screencoach
export ANDROID_HOME="$HOME/tools/android-sdk"
./scripts/build_apk.sh
```

Windows 可用 Android Studio 打开工程，或使用 `gradlew.bat assembleDebug`。

## GitHub 上传

整个 ZIP 远小于 GitHub 网页端单文件 25 MB 限制。本包未包含额外 CLI push 脚本；直接通过 GitHub 网页上传 ZIP 或创建 Release 并上传即可。

> 导入的题库/词库只保存在本机；照片题库解析会把图片发送给 DeepSeek。请勿导入或识别包含密码、支付信息等敏感内容。
